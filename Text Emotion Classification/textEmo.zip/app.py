
from flask import Flask, request, render_template
import pickle
import numpy as np
from keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

app = Flask(__name__)

# Load the tokenizer and the model
with open('model/tokenizer.pkl', 'rb') as handle:
    tokenizer = pickle.load(handle)

model = keras.models.load_model('model/emotion_model.h5')

max_length = 100  # Should be set based on the trained model

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        message = request.form['message']
        sequences = tokenizer.texts_to_sequences([message])
        padded = pad_sequences(sequences, maxlen=max_length)
        prediction = model.predict(padded)
        predicted_label = np.argmax(prediction, axis=1)
        return render_template('index.html', prediction=predicted_label)

if __name__ == '__main__':
    app.run(debug=True)
